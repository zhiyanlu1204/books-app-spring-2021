//
//  AddBookViewController.swift
//  spring-2021-final
//
//  Created by Zhiyan on 4/23/21.
//

import UIKit

protocol AddBookDelegate : class {
    func didCreate(_ book: Book)
}
class AddBookViewController : UIViewController {
    
    var bookName : String? = nil
    var author : String? = nil
    var country : String? = nil
    var date : String? = nil
    var comment : String? = nil
    weak var delegate : AddBookDelegate?
    
    @IBOutlet var addview: UIView!
    
    @IBAction func didSelectCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func didSelectDone(_ sender: Any) {
        let book : Book = didCreateNewBook()
        self.delegate?.didCreate(book)
    }
    
    func didCreateNewBook() ->Book {
        print("called")
        
        if let label = addview.viewWithTag(21) as? UITextField {
            bookName = label.text
        }
        if let label = addview.viewWithTag(22) as? UITextField {
            author = label.text
        }
        if let label = addview.viewWithTag(23) as? UITextField {
            country = label.text
        }
        if let label = addview.viewWithTag(24) as? UITextView {
            comment = label.text
        }
        let d = Date()
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        date = formatter.string(from: d)
        
        let book: Book = Book.init(t: bookName ?? "", a: author ?? "", cn: country ?? "", d: date ?? "", cm: comment ?? "")
        return book
    }
    
}
