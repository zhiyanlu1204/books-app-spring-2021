//
//  BookTableViewController.swift
//  spring-2021-final
//
//  Created by Zhiyan on 4/23/21.
//

import UIKit

class BookTableView : UITableViewController, AddBookDelegate {
    
    func didCreate(_ book: Book) {
        self.dismiss(animated: true, completion: nil)
        books.append(book)
        bookView.reloadData()
        tab!.passDataToSubViews()
        if let boolVal = map?.didLoad {
            if boolVal{
                map!.viewDidLoad()
            }
        }
    }
    
    func bookReload() {
        bookView.reloadData()
    }
    
    func mapReload() {
        tab!.passDataToSubViews()
    }
    
    var didDeleteBook : Bool = false
    
//    func passUpdatedInfoAfterDelete() {
//        if didDeleteBook {
//            tab!.passDataToSubViews()
//        }
//    }
    
    
    var tab : TabControl? = nil
    var map : MapView? = nil
    var books = [Book]()
    let myBook = Book.init(t: "The Forest of Wool and Steel", a: "Miyashita Natsu", cn: "Japan", d: "1/31/21", cm: "Tomura is startled by the hypnotic sound of a piano being tuned in his school. It seeps into his soul and transports him to the forests, dark and gleaming, that surround his beloved mountain village. From that moment, he is determined to discover more.")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // more
        books.append(myBook)
        bookView.reloadData()
    }
    
    @IBOutlet var bookView: UITableView!
    weak var delegate: AddBookDelegate?
    @IBAction func didSelectAddBook(_ sender: Any) {
        performSegue(withIdentifier: "toAddPage", sender: self)
    }
    

    // MARK: - Basic table view methods
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return books.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = bookView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let book : Book = books[indexPath.row]
        
        if let label = cell.viewWithTag(1) as? UILabel{
            label.text = book.title
        }
        if let label = cell.viewWithTag(2) as? UILabel{
            label.text = book.author
        }
        if let label = cell.viewWithTag(3) as? UILabel{
            label.text = book.country
        }
        if let label = cell.viewWithTag(4) as? UILabel{
            label.text = book.date
        }
        if let label = cell.viewWithTag(5) as? UILabel{
            label.text = book.comment
        }
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }
    
    var bookDetailsView : BookDetailsViewController? = nil
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toAddPage" {
            let navC: UINavigationController = segue.destination as! UINavigationController
            let vc: AddBookViewController = navC.topViewController as! AddBookViewController
            vc.delegate = self
        }
        if segue.identifier == "toBookDetailPage" {
            if let sd: UITableViewCell = sender as? UITableViewCell {
                let cellPosition = sd.convert(CGPoint.zero, to: self.tableView)
                let indexPath = self.tableView.indexPathForRow(at:cellPosition)
           //     let cell = self.tableView.cellForRow(at: indexPath ?? [0,0]) as! UITableViewCell
                let vc: BookDetailsViewController = segue.destination as! BookDetailsViewController
                vc.myBook = books[indexPath?.row ?? 0]
                vc.original = books[indexPath?.row ?? 0]
                vc.previous = self
                bookDetailsView = vc
                vc.mapView = map!
                print(map==nil)
            }
        }
    }
    
}
