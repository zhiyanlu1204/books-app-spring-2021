//
//  ViewController.swift
//  spring-2021-final
//
//  Created by Zhiyan on 4/23/21.
//

import UIKit

struct APIData: Codable {
    let features : [CountryInfo]
}

struct CountryInfo : Codable {
    let properties : Properties
    let geometry : Geometry
}

struct Geometry : Codable {
    let coordinates : [Double]
}

struct Properties : Codable {
    let country : String
}


class TabControl: UITabBarController {
    
    
    var country = [CountryInfo]()
    var coor = [[Double]]()
    var name = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()

        makeAPIRequest()
        
        let seconds = 0.25
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            self.passDataToSubViews()
        }
        
    }
    
    let endpoint = "https://raw.githubusercontent.com/Stefie/geojson-world/master/capitals.geojson"
    
    var features = [CountryInfo]()

    func makeAPIRequest() {
        let url = URL(string: endpoint)!
        let urlRequest = URLRequest(url: url)
        let task = URLSession.shared.dataTask(with: urlRequest){ (data, response, error) in
            guard let data = data, error == nil else {
                print("API Request failed")
                return
            }
            if let APIResponse = try? JSONDecoder().decode(APIData.self, from: data) {
                // print(APIResponse.features)
                self.updateArrs(countryInfo: APIResponse.features)
            }
        }
        task.resume()
    }
    
    func updateArrs(countryInfo : [CountryInfo]){
        self.country = countryInfo
        for c in self.country {
            self.coor.append(c.geometry.coordinates)
            self.name.append(c.properties.country)
        }
    }
    
    func passDataToSubViews() {
        let map : MapView = self.viewControllers![1] as! MapView
        map.coors = self.coor
        map.countryNames = self.name
        map.countries = self.country
        
        let nav : UINavigationController = self.viewControllers![0] as! UINavigationController
        let bookTable : BookTableView = nav.topViewController as! BookTableView
        map.bookTable = bookTable
        map.books = bookTable.books
        bookTable.tab = self
        bookTable.map = map
        bookTable.bookDetailsView?.mapView = map
    }
    

}

