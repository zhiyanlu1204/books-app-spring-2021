//
//  EditBookDetailViewController.swift
//  spring-2021-final
//
//  Created by Zhiyan on 4/23/21.
//

import UIKit


protocol BookEditDelegate: class {
    func didEditDetail(_ book: Book)
    func didDelete(_ book: Book)
}

class EditBookDetailViewController : UIViewController {
    
    var map : MapView? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let label = view.viewWithTag(41) as? UITextField {
            label.text = book.title
        }
        if let label = view.viewWithTag(42) as? UITextField {
            label.text = book.author
        }
        if let label = view.viewWithTag(43) as? UITextField {
            label.text = book.country
        }
        if let label = view.viewWithTag(44) as? UITextField {
            label.text = book.date
        }
        if let label = view.viewWithTag(45) as? UITextView {
            label.text = book.comment
        }
    }
    
    weak var delegate: BookEditDelegate?
    var book : Book = Book.init(t: "", a: "", cn: "", d: "", cm: "")
    
    @IBAction func didSelectDoneEditing(_ sender: Any) {
        if let label = view.viewWithTag(41) as? UITextField {
            book.title = label.text!
        }
        if let label = view.viewWithTag(42) as? UITextField {
            book.author = label.text!
        }
        if let label = view.viewWithTag(43) as? UITextField {
            book.country = label.text!
        }
        if let label = view.viewWithTag(44) as? UITextField {
            book.date = label.text!
        }
        if let label = view.viewWithTag(45) as? UITextView {
            book.comment = label.text!
        }
        self.delegate?.didEditDetail(book)
    }
    
    @IBAction func didSelectCancelEditing(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func didSelectDelete(_ sender: Any) {
        
        let alert = UIAlertController(title: "Deletion Confirmation", message: "Are you sure you want to delete this book?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yuppie :o", style: .default, handler: {_ in
            self.delegate?.didDelete(self.book)
        }))
        alert.addAction(UIAlertAction(title: "Oopsies nope", style: .cancel, handler: {_ in }))
        self.present(alert, animated: true, completion: nil)
        if let booVal = map?.didLoad {
            if booVal{
                map!.viewDidLoad()
            }
        }
    }
}
