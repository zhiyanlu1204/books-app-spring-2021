//
//  BookDetailsViewController.swift
//  spring-2021-final
//
//  Created by Zhiyan on 4/23/21.
//

import UIKit

class BookDetailsViewController : UIViewController, BookEditDelegate {
    
    var mapView : MapView? = nil
    
    func didEditDetail(_ book: Book) {
        self.dismiss(animated: true, completion: nil)
        myBook = book
        bookName.text = myBook.title
        Author.text = myBook.author
        Country.text = myBook.country
        Date.text = myBook.date
     //   Comment.text = myBook.comment
        commentView.text = myBook.comment
        
        var count : Int = 0
        while (count < (previous?.books.count)!) {
            if previous?.books[count].title == original.title {
                previous?.books[count].title = myBook.title
                previous?.books[count].author = myBook.author
                previous?.books[count].country = myBook.country
                previous?.books[count].date = myBook.date
                previous?.books[count].comment = myBook.comment
            }
            count = count + 1
        }
        previous?.bookReload()
        if let booVal = previous?.map?.didLoad {
            if booVal{
                previous?.map!.viewDidLoad()
            }
        }
    }
    
    
    
    func didDelete(_ book: Book) {
        self.dismiss(animated: true, completion: nil)
        bookName.text = ""
        Author.text = ""
        Country.text = ""
        Date.text = ""
     //   Comment.text = ""
        commentView.text = "You've deleted this book. She said she's never coming back now, but there's leftover fried rice in the fridge if you haven't eaten yet."
        var count : Int = 0
        var bookDelete : Book? = nil
        while (count < (previous?.books.count)!) {
            if previous?.books[count].title == original.title {
                bookDelete = previous?.books[count]
                previous?.books.remove(at: count)
                previous?.map?.books.remove(at: count)
            }
            count = count + 1
        }
        mapView?.didDeleteBook(book: bookDelete!)
        previous?.bookReload()
        previous!.didDeleteBook = true
        previous!.map?.books = previous!.books
        // was gonna call re-pass data but now the top view controller is book detail not book table so the pass function doesn't work
        if let booVal = previous?.map?.didLoad {
            if booVal{
                previous?.map!.viewDidLoad()
            }
        }
    }
    // I STILL DON'T KNOW HOW TO FUCKING DELETE THIS SHIT?????
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(myBook.title)
        didClickBookDetail()
    }
    
    weak var previous: BookTableView?
    weak var delegate: BookEditDelegate?
    var myBook : Book = Book.init(t: "", a: "", cn: "", d: "", cm: "")
    var original : Book = Book.init(t: "", a: "", cn: "", d: "", cm: "")
    
    @IBOutlet weak var bookName: UILabel!
    @IBOutlet weak var Author: UILabel!
    @IBOutlet weak var Country: UILabel!
    @IBOutlet weak var Date: UILabel!
    
    @IBOutlet weak var commentView: UITextView!
    
    
    
    
    func didClickBookDetail() {
        bookName.text = myBook.title
        Author.text = myBook.author
        Country.text = myBook.country
        Date.text = myBook.date
       // Comment.text = myBook.comment
        commentView.text = myBook.comment
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toEditDetail" {
            let vc : EditBookDetailViewController = segue.destination as! EditBookDetailViewController
            vc.delegate = self
            vc.book = myBook
            vc.map = previous?.map
        }
    }
    
}
