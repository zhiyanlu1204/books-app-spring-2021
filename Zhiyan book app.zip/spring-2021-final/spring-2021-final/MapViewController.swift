//
//  MapViewController.swift
//  spring-2021-final
//
//  Created by Zhiyan on 4/23/21.
//

import UIKit
import MapKit

class MapView : UIViewController {
    
    func didDeleteBook(book: Book) {
//        print("CALLED")
//        print(bookAnns.count)
//        print(books.count)
//        var count : Int = 0
//        var delete : Int = 0
//        while (count < books.count) {
//            if books[count].title == book.title {
//                print("ITERATION:", count)
//                books.remove(at: count)
//                delete = count
//                break
//            }
//            count = count + 1
//        }
//        let deleteAnn = bookAnns[delete]
//        print(books.count)
//        mapView.removeAnnotation(deleteAnn)
//        self.viewDidLoad()
        mapView.removeAnnotations(bookAnns)
        for book in books {
            let bookAnn : BookAnnotation = makeAnnotations(b: book)
            mapView.addAnnotation(bookAnn)
            bookAnns.append(bookAnn)
        }
    }
    
    
    @IBOutlet weak var mapView: MKMapView!
    weak var delegate : MKMapViewDelegate?
    
    var countries = [CountryInfo]()
    var countryNames = [String]()
    var coors = [[Double]]()
    var bookEditView : BookDetailsViewController? = nil
    
    var bookCountries = [String]()
    var books = [Book]()
    var bookAnns = [BookAnnotation]()
    var bookTable : BookTableView? = nil
    
    var didLoad : Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()
    
        didLoad = true
        mapView.delegate = self
        
        let initialLocation = CLLocation(latitude: 22.5431, longitude: 114.0579)
        mapView.centerToLocation(initialLocation)
        
        // this modification only works when you call viewDidLoad for the first time
        for book in books {
            let bookAnn : BookAnnotation = makeAnnotations(b: book)
            mapView.addAnnotation(bookAnn)
            bookAnns.append(bookAnn)
        }
    }
    
    func makeAnnotations(b : Book) -> BookAnnotation {
        let country : String = b.country
        var coordinate : [Double] = [0.0, 0.0]
        for c in countries {
            if c.properties.country == country {
                coordinate = c.geometry.coordinates
                print(coordinate)
            }
        }
        let coor : CLLocationCoordinate2D = CLLocationCoordinate2D.init(latitude: coordinate[1], longitude: coordinate[0])
        let bookAnn = BookAnnotation.init(title: b.title, subtitle: b.author, coordinate: coor)
        return bookAnn
        }
    
    var name : String = ""
}

class BookAnnotation: NSObject, MKAnnotation {
    let coordinate: CLLocationCoordinate2D
    let title : String? // book name
    let subtitle: String? // author
    
    init(title: String?,
        subtitle: String?,
        coordinate: CLLocationCoordinate2D){
        self.title = title
        self.subtitle = subtitle
        self.coordinate = coordinate
        
        super.init()
    }
    
    
}
// 1, add a button to callout
// 2, when tapped (is a func), perform a segue to show book details
// https://youtu.be/V3lT15uOGZI
extension MapView : MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let annotation = annotation as? BookAnnotation else {
            return nil
        }
        let identifier = "book"
        var view : MKAnnotationView
        if let deqView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) {
            deqView.annotation = annotation
            view = deqView
         //   view.image = UIImage(named: "oneBook.png")
        } else {
            view = MKAnnotationView(
              annotation: annotation,
              reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            view.image = UIImage(named: "oneBook.png")
        }
        return view
    }
    
    // below is everything that has to do with showing book details on map segue pop up
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        print("PERFORM")
        let ann = view.annotation as! BookAnnotation
        name = ann.title!
        var book : Book? = nil
        for bk in books {
            if bk.title == name {
                book = bk
            }
        }
        performSegue(withIdentifier: "mapToBookDetail", sender: BookAnnotation.self)
    }
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("HERE")
        if segue.identifier == "mapToBookDetail" {
            print("INHERE")
            let vc = segue.destination as! MapBookView
            // maybe makr "book" sth that disnt need unwrappong?
            var book : Book? = nil
            for bk in books {
                if bk.title == name {
                    book = bk
                }
            }
            vc.book = book!
            // why doesn't prepare for segue work? it keeps saying that something is Nil
            }
        }


//override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        print("HERE")
//        if segue.identifier == "mapToBookDetail" {
//            print("INHERE")
//            let vc = segue.destination as! BookDetailsViewController
//            self.delegate = vc as! MKMapViewDelegate
//        }
//    }
//}
}

private extension MKMapView {
  func centerToLocation(
    _ location: CLLocation,
    regionRadius: CLLocationDistance = 10000000
  ) {
    let coordinateRegion = MKCoordinateRegion(
      center: location.coordinate,
      latitudinalMeters: regionRadius,
      longitudinalMeters: regionRadius)
    setRegion(coordinateRegion, animated: true)
  }
}
