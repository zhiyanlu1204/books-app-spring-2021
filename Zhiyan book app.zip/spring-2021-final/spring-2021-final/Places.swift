//
//  Places.swift
//  spring-2021-final
//
//  Created by Zhiyan on 4/23/21.
//

import Foundation

struct Place {
    var bookTitle : String
    var bookAuthor : String
    var placeName : String
    var placeQuote : String
    var addDate : String
    var coordinate : [Float]
    
    init(title: String, author: String, place: String, quote: String, date: String, coordinate: [Float]) {
        self.bookTitle = title
        self.bookAuthor = author
        self.placeName = place
        self.placeQuote = quote
        self.addDate = date
        self.coordinate = coordinate
    }
    
    // initializer for when there is no quote
    init(title: String, author: String, place: String, date: String, coordinate: [Float]) {
        self.bookTitle = title
        self.bookAuthor = author
        self.placeName = place
        self.placeQuote = ""
        self.addDate = date
        self.coordinate = coordinate
    }
}
