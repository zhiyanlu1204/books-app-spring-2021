//
//  Book.swift
//  spring-2021-final
//
//  Created by Zhiyan on 4/23/21.
//

import Foundation

class Book {
    var title : String
    var author : String
    var country : String
    var date : String
    var comment : String
    
    init(t: String, a: String, cn: String, d: String, cm: String){
        self.title = t
        self.author = a
        self.country = cn
        self.date = d
        self.comment = cm
    }
}
