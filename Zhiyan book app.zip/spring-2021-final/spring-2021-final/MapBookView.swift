//
//  MapBookView.swift
//  spring-2021-final
//
//  Created by Zhiyan on 4/30/21.
//

import UIKit

class MapBookView : UIViewController {
    
    // who should be the delegate??
    
    func didTapButton(_ book: Book) {
        performSegue(withIdentifier: "mapToBookDetail", sender: BookAnnotation.self)
        mapName.text = book.title
    }
    
    var book : Book? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapName.text = book?.title
        mapAuthor.text = book?.author
        mapCountry.text = book?.country
        mapDate.text = book?.date
       // mapComment.text = book?.comment
        commentView.text = book?.comment
    }
    
    @IBOutlet var mapBookView: UIView!
    @IBOutlet weak var mapName: UILabel!
    @IBOutlet weak var mapAuthor: UILabel!
    @IBOutlet weak var mapCountry: UILabel!
    @IBOutlet weak var mapDate: UILabel!
    @IBOutlet weak var commentView: UITextView!
    
}
